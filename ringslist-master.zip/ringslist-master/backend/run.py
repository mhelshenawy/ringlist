from app import app

# ===========================================================================
# *               `python run.py`
# ? Module to launch app in development mode.
# Deployment module executes app from app.py
# ===========================================================================


app.run(debug=True)
